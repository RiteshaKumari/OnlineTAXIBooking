﻿namespace Taxi.Model
{
    public class Signin
    {
        public string Email { get; set; } = null!;

        public string Password { get; set; } = null!;
    }
}
